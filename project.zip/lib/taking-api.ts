import { TakingPayload } from "@/types/taking";

const BASE = process.env.NEXT_PUBLIC_API_URL;

export async function createTaking(payload: TakingPayload) {
  console.log("data create taking: ", payload);
  const res = await fetch(`${BASE}/takings`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    const err = await res.json();
    console.log("Gagal cok");
    throw new Error(err.message ?? "Gagal menambah pengambilan");
  }

  return res.json();
}
