import { ProductPayload } from "@/types/product";

const BASE = process.env.NEXT_PUBLIC_API_URL;

export async function createProduct(payload: ProductPayload) {
  const res = await fetch(`${BASE}/products`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.message ?? "Gagal menambah produk");
  }

  return res.json();
}

export async function updateProduct(id: number, payload: ProductPayload) {
  const res = await fetch(`${BASE}/products/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.message ?? "Gagal mengupdate produk");
  }

  return res.json();
}

export async function deleteProduct(id: number) {
  const res = await fetch(`${BASE}/products/${id}`, {
    method: "DELETE",
  });

  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.message ?? "Gagal menghapus produk");
  }

  return res.json();
}
