// // src/lib/api.ts

// import { Product } from "@/types/product";

// const BASE_URL = process.env.NEXT_PUBLIC_API_URL;

// export async function getProducts(): Promise<Product[]> {
//   const response = await fetch(`${BASE_URL}/products`, {
//     method: "GET",
//     headers: {
//       "Content-Type": "application/json",
//     },

//     // nextjs caching strategy
//     cache: "no-store",
//   });

//   if (!response.ok) {
//     throw new Error("Failed to fetch products");
//   }

//   const result: ApiResponse<Product[]> = await response.json();

//   if (!result.success) {
//     throw new Error(result.message);
//   }

//   return result.data;
// }
