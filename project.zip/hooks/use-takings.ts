import useSWR from "swr";
import { TakingsResponse, Taking } from "@/types/taking";

const fetcher = (url: string): Promise<TakingsResponse> =>
  fetch(url).then((res) => {
    if (!res.ok) throw new Error("Gagal mengambil data taking");
    return res.json();
  });

export function useTakings() {
  const { data, error, isLoading, mutate } = useSWR<TakingsResponse>(
    `${process.env.NEXT_PUBLIC_API_URL}/takings`,
    fetcher,
  );

  return {
    takings: data?.data ?? ([] as Taking[]),
    isLoading,
    isError: !!error,
    mutate,
  };
}
