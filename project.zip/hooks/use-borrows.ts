import useSWR from "swr";
import { BorrowResponse, Borrow } from "@/types/borrow";

const fetcher = (url: string): Promise<BorrowResponse> =>
  // ← ini yang berubah
  fetch(url).then((res) => {
    if (!res.ok) throw new Error("Gagal mengambil data borrowing");
    return res.json();
  });

export function useBorrows() {
  const { data, error, isLoading, mutate } = useSWR<BorrowResponse>(
    `${process.env.NEXT_PUBLIC_API_URL}/borrows`, // ← ini juga, bukan /takings
    fetcher,
  );

  return {
    borrows: data?.data ?? ([] as Borrow[]),
    isLoading,
    isError: !!error,
    mutate,
  };
}
