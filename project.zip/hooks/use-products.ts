"use client";

import useSWR from "swr";
import { Product } from "@/types/product";

const fetcher = async (url: string): Promise<Product[]> => {
  const res = await fetch(url);

  if (!res.ok) {
    throw new Error("Failed to fetch products");
  }

  const json = await res.json();

  return json.data;
};

export function useProducts() {
  const { data, error, isLoading, mutate } = useSWR<Product[]>(
    `${process.env.NEXT_PUBLIC_API_URL}/products`,
    fetcher,
  );
  console.log("data:", data);

  return {
    products: data ?? [],
    isLoading,
    isError: error,
    mutate,
  };
}
