import useSWR from "swr";
import { UnitsResponse, Unit } from "@/types/unit";

const fetcher = (url: string): Promise<UnitsResponse> =>
  fetch(url).then((res) => {
    if (!res.ok) throw new Error("Gagal mengambil data unit");
    return res.json();
  });

export function useUnits() {
  const { data, error, isLoading, mutate } = useSWR<UnitsResponse>(
    `${process.env.NEXT_PUBLIC_API_URL}/units`,
    fetcher,
  );

  return {
    units: data?.data ?? ([] as Unit[]),
    isLoading,
    isError: !!error,
    mutate, // ← tambah ini
  };
}
