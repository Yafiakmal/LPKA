import { UnitPayload } from "@/types/unit";

const BASE = process.env.NEXT_PUBLIC_API_URL;

function authHeaders(): HeadersInit {
  const token = localStorage.getItem("auth_token");
  return {
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
}

export async function createUnit(payload: UnitPayload) {
  const res = await fetch(`${BASE}/units`, {
    method: "POST",
    headers: authHeaders(),
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.message ?? "Gagal menambah unit");
  }

  return res.json();
}

export async function updateUnit(id: number, payload: UnitPayload) {
  const res = await fetch(`${BASE}/units/${id}`, {
    method: "PUT",
    headers: authHeaders(),
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.message ?? "Gagal mengupdate unit");
  }

  return res.json();
}

export async function deleteUnit(id: number) {
  const res = await fetch(`${BASE}/units/${id}`, {
    method: "DELETE",
    headers: authHeaders(),
  });

  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.message ?? "Gagal menghapus unit");
  }

  return res.json();
}
