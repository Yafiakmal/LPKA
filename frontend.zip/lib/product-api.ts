import { ProductPayload } from "@/types/product";

const BASE = process.env.NEXT_PUBLIC_API_URL;

// Helper: ambil token dari localStorage
function authHeaders(): HeadersInit {
  const token = localStorage.getItem("auth_token");
  return {
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
}

export async function createProduct(payload: ProductPayload) {
  const res = await fetch(`${BASE}/products`, {
    method: "POST",
    headers: authHeaders(),
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.message ?? "Gagal menambah produk");
  }

  return res.json();
}

export async function updateProduct(id: number, payload: ProductPayload) {
  const res = await fetch(`${BASE}/products/${id}`, {
    method: "PUT",
    headers: authHeaders(),
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.message ?? "Gagal mengupdate produk");
  }

  return res.json();
}

export async function deleteProduct(id: number) {
  const res = await fetch(`${BASE}/products/${id}`, {
    method: "DELETE",
    headers: authHeaders(),
  });

  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.message ?? "Gagal menghapus produk");
  }

  return res.json();
}
