// middleware.ts
import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

const protectedRoutes = ["/borrows", "/items", "/units", "/takings"];

export function middleware(request: NextRequest) {
  const token = request.cookies.get("auth_token")?.value;
  const isProtected = protectedRoutes.some((r) =>
    request.nextUrl.pathname.startsWith(r),
  );

  if (isProtected && !token) {
    const loginUrl = new URL("/login", request.url);
    loginUrl.searchParams.set("redirect", request.nextUrl.pathname);
    return NextResponse.redirect(loginUrl);
  }

  return NextResponse.next();
}
