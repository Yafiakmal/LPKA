"use client";

import * as React from "react";

import { NavMain } from "@/components/nav-main";
import { NavProjects } from "@/components/nav-projects";
import { NavUser } from "@/components/nav-user";
import { TeamSwitcher } from "@/components/team-switcher";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarRail,
} from "@/components/ui/sidebar";
import { HugeiconsIcon } from "@hugeicons/react";
import {
  LayoutBottomIcon,
  AudioWave01Icon,
  CommandIcon,
  ComputerTerminalIcon,
  RoboticIcon,
  BookOpen02Icon,
  Settings05Icon,
  CropIcon,
  PieChartIcon,
  MapsIcon,
  Archive04Icon,
  Hold02Icon,
  SignLanguageCIcon,
  DashboardSquare01Icon,
} from "@hugeicons/core-free-icons";
import { Tooltip, TooltipContent, TooltipTrigger } from "./ui/tooltip";
import Image from "next/image";
import { features } from "process";

// This is sample data.
const data = {
  user: {
    name: "Dwi Hartono",
    email: "lpka@gmail.com",
    avatar: "/avatars/shadcn.jpg",
  },
  teams: [
    {
      name: "Lembaga Pembinaan Khusus Anak Kelas 1 Martapura",
      logo: <HugeiconsIcon icon={LayoutBottomIcon} strokeWidth={2} />,
      plan: "Inventory",
    },
  ],
  navMain: [
    {
      title: "Dashboard",
      url: "#",
      icon: <HugeiconsIcon icon={DashboardSquare01Icon} />,
      isActive: true,
    },
    {
      title: "Items",
      url: "#",
      icon: <HugeiconsIcon icon={Archive04Icon} />,
      items: [
        {
          title: "Genesis",
          url: "#",
        },
        {
          title: "Explorer",
          url: "#",
        },
        {
          title: "Quantum",
          url: "#",
        },
      ],
    },
    {
      title: "Peminjaman",
      url: "#",
      icon: <HugeiconsIcon icon={SignLanguageCIcon} />,
      items: [
        {
          title: "Introduction",
          url: "#",
        },
        {
          title: "Get Started",
          url: "#",
        },
        {
          title: "Tutorials",
          url: "#",
        },
        {
          title: "Changelog",
          url: "#",
        },
      ],
    },
    {
      title: "Pengambilan",
      url: "#",
      icon: <HugeiconsIcon icon={Hold02Icon} />,
      items: [
        {
          title: "General",
          url: "#",
        },
        {
          title: "Team",
          url: "#",
        },
        {
          title: "Billing",
          url: "#",
        },
        {
          title: "Limits",
          url: "#",
        },
      ],
    },
  ],
  features: [
    {
      name: "Dashboard",
      url: "/dashboard",
      icon: <HugeiconsIcon icon={DashboardSquare01Icon} strokeWidth={2} />,
    },
    {
      name: "Items",
      url: "/items",
      icon: <HugeiconsIcon icon={Archive04Icon} strokeWidth={2} />,
    },
    {
      name: "Peminjaman",
      url: "/borrows",
      icon: <HugeiconsIcon icon={SignLanguageCIcon} strokeWidth={2} />,
    },
    {
      name: "Pengambilan",
      url: "/takings",
      icon: <HugeiconsIcon icon={Hold02Icon} strokeWidth={2} />,
    },
  ],
};

export function AppSidebar({ ...props }: React.ComponentProps<typeof Sidebar>) {
  return (
    <Sidebar collapsible="icon" {...props}>
      <SidebarHeader>
        {/* <TeamSwitcher teams={data.teams} /> */}
        <Tooltip>
          <TooltipTrigger asChild>
            <div className="flex items-center gap-2.5 px-2 py-2 cursor-default select-none">
              {/* Logo icon */}
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md overflow-hidden group-data-[collapsible=icon]:hidden">
                <Image
                  src="/logo.png"
                  alt="Logo LPKA Kelas 1 Martapura"
                  width={32}
                  height={32}
                  className="object-contain"
                />
              </div>

              {/* Title — disembunyikan saat sidebar collapsed */}
              <div className="flex flex-col leading-none overflow-hidden group-data-[collapsible=icon]:hidden">
                <span className="text-sm font-semibold truncate">
                  LPKA Kelas 1 Martapura
                </span>
                <span className="text-[10px] text-muted-foreground font-medium tracking-wide uppercase">
                  Inventory System
                </span>
              </div>
            </div>
          </TooltipTrigger>

          <TooltipContent side="right" className="text-xs">
            Lembaga Pembinaan Khusus Anak Kelas 1 Martapura
          </TooltipContent>
        </Tooltip>
      </SidebarHeader>
      <SidebarContent>
        {/* <NavMain items={data.navMain} /> */}
        <NavProjects projects={data.features} />
      </SidebarContent>
      {/* <SidebarFooter>
        <NavUser user={data.user} />
      </SidebarFooter> */}
      <SidebarRail />
    </Sidebar>
  );
}
